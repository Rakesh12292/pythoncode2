# sample-flask-app
A sample flask app to be used for deploying anywhere as a demo
